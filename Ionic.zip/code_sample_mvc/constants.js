angular.module('starter')
 
.constant('AUTH_EVENTS', {
	notAuthenticated: 'auth-not-authenticated',
	notAuthorized: 'auth-not-authorized'
})
 
.constant('USER_ROLES', {
	admin: 'admin_role',
	public: 'public_role'
})

.constant('USER_CREDENTIAL', {
	user_key: 'username',
	pass_key: 'password'
})

.constant('BACKEND_URL', {
	baseURL: 'http://www.backend.com/',
	loginURL: 'login.php',
	verifyReferralURL: 'verifyReferral.php',
	verifyAppointmentURL: 'verifyAppointment.php',
	programURL : 'program.php',
	referralURL : 'referral.php',
	referralByIdURL : 'referralById.php',
	referralByProgramIdURL: 'referralByProgramId.php',
	setPriorityURL: 'setReferralPriority.php',
	sendReferralURL : 'referral_send.php',
	addReferralURL: 'referral_add.php',
	emailReferralURL: 'referral_email.php',
	appointmentURL: 'appointment.php',
	confirmAppointmentURL: 'appointment_confirm.php',
	editAppointmentURL: 'appointment_edit.php'
});