angular.module('starter')

.controller('ReferralCtrl', function($rootScope, $scope, $state, ReferralService, DataService, AuthService, $ionicPopup, AppointmentService) {
	
	// Init Calendar Modal via "inline" Magnific Popup
	$('#compose-event-btn').magnificPopup({
		items: {
		  	src: '#calendarEvent',
		  	type: 'inline'
		},
	  	removalDelay: 500, //delay removal by X to allow out-animation
		callbacks: {
			beforeOpen: function(e) {
			  	// we add a class to body indication overlay is active
			  	// We can use this to alter any elements such as form popups
			  	// that need a higher z-index to properly display in overlays
			  	$('body').addClass('mfp-bg-open');
			  	this.st.mainClass = this.st.el.attr('data-effect');
			},
			afterClose: function(e) {
			  	$('body').removeClass('mfp-bg-open');
			}
		},
	  	midClick: true // allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source.
	});

	$scope.dateOptions = {
		numberOfMonths: 1,
		dateFormat: 'yy/mm/dd',
		prevText: '<i class="fa fa-chevron-left"></i>',
		nextText: '<i class="fa fa-chevron-right"></i>',
		showButtonPanel: false,
		beforeShow: function(input, inst) {
		  	var newclass = 'admin-form';
			var themeClass = $(this).parents('.admin-form').attr('class');
			var smartpikr = inst.dpDiv.parent();
			if (!smartpikr.hasClass(themeClass)) {
				inst.dpDiv.wrap('<div class="' + themeClass + '"></div>');
			}
		}
	};

	// Init Theme Core
	Core.init();

	$scope.referrals = new Array();

	$scope.formatReferral = function () {
	  	$scope.newReferral.doctor_id = AuthService.user_id();
	  	$scope.newReferral.status = "pending";
	  	$scope.newReferral.program = "";
	  	$scope.newReferral.patientName = "";
	  	$scope.newReferral.birthDate = "";
	  	$scope.newReferral.gender = "";
	  	$scope.newReferral.address = "";
	  	$scope.newReferral.mobile = "";
	  	$scope.newReferral.phone = "";
	  	$scope.newReferral.email = "";
	  	$scope.newReferral.comment = "";
	};

	$scope.selProgram = null;
	$scope.getProgram = function () {
		DataService.getPrograms(function(response) {
			if(response == "null")
			  	return;
			else {
				$scope.programs = new Array();
				var itemCount = response.length;
				for(i=0; i<itemCount; i++)
				{
					var item = JSON.parse(JSON.stringify(response[i]));
					$scope.programs.push({id: item.id, name: item.name, length: item.duration});
				}
				$scope.selProgram = $scope.programs[0];
			}
		});
	};

	$scope.getProgramName = function (program_id) {
		for (key in $scope.programs) {
			if($scope.programs[key].id == program_id) {
			  	return $scope.programs[key].name;
			}
		}
	};

	$scope.getReferral = function () {
		ReferralService.getReferrals(AuthService.user_id(), function(response) {
			if(response == "null")
			  	return;
			else {
				$scope.referrals = [];
				var itemCount = response.length;
				for(i=0; i<itemCount; i++)
				{
					var item = JSON.parse(JSON.stringify(response[i]));
					$scope.referrals.push(item);
				}
			}
		});
	};

	$scope.printIndex = function (currentReferral) {
	  	return $scope.referrals.indexOf(currentReferral) + 1;
	}

	$scope.createReferral = function () {
		$scope.newReferral.program = $scope.selProgram.id;
		ReferralService.addReferral($scope.newReferral, function(data){
		  	$.magnificPopup.close();
			if(data == "null") {
				$ionicPopup.alert({
					title: 'Error',
					template: 'Referral cannot be created.'
				});
				return;
			}
			else {
				$ionicPopup.alert({
					title: 'Success',
					template: 'Email sent successfully.'
				});
			  	$scope.referrals.push(data);
			}
			$scope.formatReferral();
		});
	};

	$scope.resendLink = function (referral) {
	  	if(referral.status == 'pending') {
			var confirmPopup = $ionicPopup.confirm({
				title: 'Referral',
				template: 'Are you sure you want to send email?'
			});
			confirmPopup.then(function(res) {
				if(res) {
					ReferralService.sendEmail(referral, function(data) {
					  	if(data == 'success') {
							$ionicPopup.alert({
							  	title: 'Success',
							  	template: 'Email sent successfully.'
							});
						}
					 	else {
							$ionicPopup.alert({
							  title: 'Error',
							  template: 'Email has not been sent.'
							});
					  	}
					});
				} else {
					console.log('You are not sure');
				}
			});
	  	}
	}

	$scope.newReferral = [];
	$scope.getProgram();
	$scope.getReferral();
	$scope.formatReferral();
});