angular.module('starter')

.service('ReferralService', function($q, $rootScope, $http, $state, $ionicPopup, BACKEND_URL, AuthService) {
    var getReferrals = function(user_id, callback){
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.referralURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param({user_id : user_id})
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            if(data == "fail") {
              callback("null");
              return;
            }
            callback(JSON.parse(JSON.stringify(data)));
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
              title: 'Error',
              template: JSON.stringify(status)
            });
        });
    };

    var getReferral = function (refId, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.referralByIdURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param({referralId : refId})
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            if(data == "fail") {
              callback("null");
              return;
            }
            callback(JSON.parse(JSON.stringify(data)));
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
              title: 'Error',
              template: JSON.stringify(status)
            });
        });
    }

    var getReferralsByProgramId = function (programId, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.referralByProgramIdURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param({programId : programId})
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            if(data == "fail") {
              callback("null");
              return;
            }
            callback(JSON.parse(JSON.stringify(data)));
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
              title: 'Error',
              template: JSON.stringify(status)
            });
        });
    }

    var addReferral = function(newReferral, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.addReferralURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param(
                {
                    doctor_id : newReferral.doctor_id,
                    status : newReferral.status,
                    program : newReferral.program,
                    patientName : newReferral.patientName,
                    birthDate : moment(newReferral.birthDate).format("YYYY/MM/DD"),
                    gender : newReferral.gender,
                    address : newReferral.address,
                    mobile : newReferral.mobile,
                    phone : newReferral.phone,
                    email : newReferral.email,
                    comment : newReferral.comment
                }
            )
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            console.log(data);
            var result = JSON.parse(JSON.stringify(data));
            if(result.status == "fail") {
              callback("null");
              return;
            }
            callback(result.data);
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
              title: 'Network error',
              template: JSON.stringify(data)
            });
        });
    };

    var sendEmail = function(referral, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.emailReferralURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param(
                {
                    referralId: referral.id,
                    email: referral.email,
                    doctor_id: referral.doctor_id,
                    token: referral.token
                }
            )
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            console.log(data);
            var result = JSON.parse(JSON.stringify(data));
            if(result.status == "fail") {
              callback("null");
              return;
            }
            callback('success');
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
              title: 'Network error',
              template: JSON.stringify(data)
            });
        });
    };

    var setPriority = function(datas, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.setPriorityURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: datas
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            console.log(data);
            callback(data);
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
                title: 'Network error',
                template: JSON.stringify(data)
            });
        });
    };

    var sendReferral = function(refId, startDate, callback) {
        AuthService.show_spinner();
        $http({
            url: BACKEND_URL.baseURL+BACKEND_URL.sendReferralURL,
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            data: $.param(
                {
                    referral_id: refId,
                    startDate: moment(startDate).format()
                }
            )
        }).
        success(function(data, status, headers, config) {
            AuthService.hide_spinner();
            callback(data);
        }).
        error(function(data, status, headers, config) {
            AuthService.hide_spinner();
            $ionicPopup.alert({
                title: 'Network error',
                template: JSON.stringify(data)
            });
        });
    };

    return {
        getReferrals : getReferrals,
        addReferral : addReferral,
        sendEmail: sendEmail,
        getReferral: getReferral,
        getReferralsByProgramId: getReferralsByProgramId,
        setPriority: setPriority,
        sendReferral: sendReferral
    };
});